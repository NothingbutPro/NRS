package com.example.android.nrs.Model;

public class RoProduct {
    String prodImage;
    String roName;
    String roPrice;
    String roDescrip;

    public String getProdImage() {
        return prodImage;
    }

    public void setProdImage(String prodImage) {
        this.prodImage = prodImage;
    }

    public String getRoName() {
        return roName;
    }

    public void setRoName(String roName) {
        this.roName = roName;
    }

    public String getRoPrice() {
        return roPrice;
    }

    public void setRoPrice(String roPrice) {
        this.roPrice = roPrice;
    }

    public String getRoDescrip() {
        return roDescrip;
    }

    public void setRoDescrip(String roDescrip) {
        this.roDescrip = roDescrip;
    }
}
