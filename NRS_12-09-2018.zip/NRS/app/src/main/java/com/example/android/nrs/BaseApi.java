package com.example.android.nrs;

/**
 * Created by android on 8/6/2018.
 */

public class BaseApi {

    public static final String BASEURL = "https://spellclasses.co.in";

    public static final String IMAGE_URL = BASEURL + "/NRS/uploads/product/";

}
