package com.example.android.nrs.Model;

public class SparePart {
    String spareImage;
    String spareName;
    String sparePrice;
    String spareDescrip;

    public String getSpareImage() {
        return spareImage;
    }

    public void setSpareImage(String spareImage) {
        this.spareImage = spareImage;
    }

    public String getSpareName() {
        return spareName;
    }

    public void setSpareName(String spareName) {
        this.spareName = spareName;
    }

    public String getSparePrice() {
        return sparePrice;
    }

    public void setSparePrice(String sparePrice) {
        this.sparePrice = sparePrice;
    }

    public String getSpareDescrip() {
        return spareDescrip;
    }

    public void setSpareDescrip(String spareDescrip) {
        this.spareDescrip = spareDescrip;
    }
}
