package com.example.android.nrs;

import android.app.Dialog;
import android.app.FragmentManager;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.android.nrs.SharedPreference.SessionManager;
import com.example.android.nrs.Utility.Connectivity;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpParams;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import javax.net.ssl.HttpsURLConnection;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;


public class ComplaintFragment extends Fragment implements
        AdapterView.OnItemSelectedListener {


    private static final String TAG = "";
    // String[] country = { "Cooler", "Fan", "Washing Machine", "Television", "AC" };
    Spinner product_name;
    ArrayAdapter ad_product;
    ArrayList<String> product_list;
    String Selected_product;
    String result;
    String server_url;
    String mobile_no = "";

    AppPreference appPreference;
    private OkHttpClient mClient = new OkHttpClient();
    private Context mContext;


    EditText name, mob_no, address_, model_no_, serial_no_, pincode_;
    //Spinner product_name;

    String Name, Mobile_no, Model_no, Serial_no, Address, Pincode;

    String CustMobileno, CustName, StrModel, StrSerial, StrProduct, StrPincode, StrAddress;

    private OnFragmentInteractionListener mListener;
    private SessionManager manager;
    private String strCompCode = "";
    private boolean comp_Done = true;
    private Button submit, bt_Otp;
    private String strMob_otp;

    public ComplaintFragment() {
        // Required empty public constructor
    }

/*
    public static ComplaintFragment newInstance(String param1, String param2) {
        ComplaintFragment fragment = new ComplaintFragment();
        Bundle args = new Bundle();

        fragment.setArguments(args);
        return fragment;
    }*/

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_complaint, container, false);
        manager = new SessionManager(getActivity());


        // CustName = AppPreference.getCustName(getActivity());
        /*CustMobileno = manager.getMobile();
        CustName = manager.getUsername();
        StrModel = manager.getModel();
        StrSerial = manager.getSerial();
        StrProduct = manager.getProduct();
        StrPincode = manager.getPincode();
        StrAddress= manager.getAddress();*/


        submit = (Button) view.findViewById(R.id.submit);
        bt_Otp = (Button) view.findViewById(R.id.resetOtp);
        name = (EditText) view.findViewById(R.id.customer_name);
        mob_no = (EditText) view.findViewById(R.id.mobile_no);
        address_ = (EditText) view.findViewById(R.id.address);
        product_name = (Spinner) view.findViewById(R.id.spinner1);
        model_no_ = (EditText) view.findViewById(R.id.model_no);
        serial_no_ = (EditText) view.findViewById(R.id.serial_no);
        pincode_ = (EditText) view.findViewById(R.id.pincode);


        // name.setText(CustName);
        mob_no.setText(CustMobileno);
        name.setText(CustName);
        model_no_.setText(StrModel);
        serial_no_.setText(StrSerial);
//        product_name.setText(CustName);
        pincode_.setText(StrPincode);
        address_.setText(StrAddress);

    /*    if (Connectivity.isNetworkAvailable(getActivity())) {
            new GetComplaintList().execute();
        } else {
            Toast.makeText(getActivity(), "no Internet", Toast.LENGTH_SHORT).show();
        }*/


        product_list = new ArrayList<>();
        product_list.add("RO");
        product_list.add("Gizer");
        product_list.add("Washing Machine");
        product_list.add("Refigerator");
        product_list.add("D-Freeze");
        product_list.add("AC");


        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Name = name.getText().toString().trim();
                Mobile_no = mob_no.getText().toString();
                Model_no = model_no_.getText().toString();
                Serial_no = serial_no_.getText().toString();
                Address = address_.getText().toString();
                Pincode = pincode_.getText().toString();


                if (Name.isEmpty()) {
                    name.setError("Name is required");
                    name.requestFocus();
                    return;
                }
                if (Mobile_no.isEmpty()) {
                    mob_no.setError("Mobile number is required");
                    mob_no.requestFocus();
                    return;
                }
                if (Model_no.isEmpty()) {
                    model_no_.setError("Model No. is required");
                    model_no_.requestFocus();
                    return;
                }
                if (Serial_no.isEmpty()) {
                    serial_no_.setError("Serial no is required");
                    serial_no_.requestFocus();
                    return;
                }
                if (Address.isEmpty()) {
                    address_.setError("Address is required");
                    address_.requestFocus();
                    return;
                }
                if (Pincode.isEmpty()) {
                    pincode_.setError("Pincode is required");
                    pincode_.requestFocus();
                    return;
                } else if (Pincode.length() != 6) {
                    pincode_.setError("Pincode Should Be 6 Digits");
                    pincode_.requestFocus();
                    return;
                }

                if (Connectivity.isNetworkAvailable(getActivity())) {
//                    if (!manager.isCompDone()) {
                    manager.storeComplainData(Name, Mobile_no,Address,Pincode,Selected_product,Model_no,Serial_no);
                    Intent intent = new Intent(getActivity(), OtpActivity.class);
                    startActivity(intent);
                    getActivity().finish();
                    /*} else {
                        Toast.makeText(getActivity(), "Your Are Not Eligible For New Complain", Toast.LENGTH_LONG).show();
                    }*/
                } else {
                    Toast.makeText(getActivity(), "no Internet", Toast.LENGTH_SHORT).show();
                }
            }
        });


        product_name = (Spinner) view.findViewById(R.id.spinner1);
        ad_product = new ArrayAdapter(getContext(), android.R.layout.simple_spinner_item, product_list);
        ad_product.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        product_name.setAdapter(ad_product);
        product_name.setOnItemSelectedListener(this);

        bt_Otp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                otpDialog();
            }
        });

        return view;
    }

    private void otpDialog() {

        final Dialog dialog = new Dialog(getActivity());
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.otp_reset_layout);
        // dialog.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        dialog.show();

        // final Spinner spinner = (Spinner) dialog.findViewById(R.id.spinner1);
        final TextView text1 = (TextView) dialog.findViewById(R.id.text1);
        final EditText editText1 = (EditText) dialog.findViewById(R.id.editText1);

        Button button = (Button) dialog.findViewById(R.id.button1);

        button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                dialog.dismiss();
                strMob_otp = editText1.getText().toString();
                new SendJsonDataToServer(strMob_otp).execute();
                Log.e("OTTP", strMob_otp);
            }
        });

    }


    private boolean validate() {
        if (name.getText().toString().trim().equals(""))
            return false;
        else if (address_.getText().toString().trim().equals(""))
            return false;
        else if (mob_no.getText().toString().trim().equals(""))
            return false;
        else if (model_no_.getText().toString().trim().equals(""))
            return false;
        else if (serial_no_.getText().toString().trim().equals(""))
            return false;
        else if (serial_no_.getText().toString().trim().equals(""))
            return false;
        else if (product_name.getSelectedItem().toString().trim().equals(""))
            return false;
        else
            return true;
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        Selected_product = product_name.getSelectedItem().toString();
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    //---------------------------------------------------------------------

    class SendJsonDataToServer extends AsyncTask<String, String, String> {

        ProgressDialog dialog;
        String strMob_otp;

        public SendJsonDataToServer(String strMob_otp) {
            this.strMob_otp = strMob_otp;
        }

        protected void onPreExecute() {
            dialog = new ProgressDialog(getContext());
            dialog.show();

        }

        protected String doInBackground(String... arg0) {

            try {

                URL url = new URL("https://www.spellclasses.co.in/NRS/Api/resendotp");


                JSONObject postDataParams = new JSONObject();
                postDataParams.put("mobile", strMob_otp);

                Log.e("postDataParams", postDataParams.toString());

                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(15000 /* milliseconds*/);
                conn.setConnectTimeout(15000  /*milliseconds*/);
                conn.setRequestMethod("POST");
                conn.setDoInput(true);
                conn.setDoOutput(true);

                OutputStream os = conn.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = conn.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {

                    BufferedReader r = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    StringBuilder result = new StringBuilder();
                    String line;
                    while ((line = r.readLine()) != null) {
                        result.append(line);
                    }
                    r.close();
                    return result.toString();

                } else {
                    return new String("false : " + responseCode);
                }
            } catch (Exception e) {
                return new String("Exception: " + e.getMessage());
            }

        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null) {
                dialog.dismiss();
                Intent intent = new Intent(getContext(), OtpActivity.class);
                startActivity(intent);
            }
        }

        public String getPostDataString(JSONObject params) throws Exception {

            StringBuilder result = new StringBuilder();
            boolean first = true;

            Iterator<String> itr = params.keys();

            while (itr.hasNext()) {

                String key = itr.next();
                Object value = params.get(key);

                if (first)
                    first = false;
                else
                    result.append("&");

                result.append(URLEncoder.encode(key, "UTF-8"));
                result.append("=");
                result.append(URLEncoder.encode(value.toString(), "UTF-8"));

            }
            return result.toString();
        }


    }

    //-------------------------------------------------------------------------------------

    class GetComplaintList extends AsyncTask<String, String, String> {
        String output = "";
        ProgressDialog dialog;

        @Override
        protected void onPreExecute() {
            dialog = new ProgressDialog(getActivity());
            dialog.setMessage("Processing");
            dialog.setCancelable(true);
            dialog.show();
            super.onPreExecute();
            //movieList = new ArrayList<>();
        }

        @Override
        protected String doInBackground(String... params) {

            try {
                server_url = "http://spellclasses.co.in/NRS/api/complianDetailsbyid?complain_id=" + strCompCode;
                Log.e("COMPCODE", strCompCode);
            } catch (Exception e) {
                e.printStackTrace();
            }
            Log.e("sever_url>>>>>>>>>", server_url);
            output = HttpHandler.makeServiceCall(server_url);
            System.out.println("getcomment_url" + output);
            return output;
        }

        @Override
        protected void onPostExecute(String output) {
            if (output == null) {
                dialog.dismiss();
            } else {
                try {
                    dialog.dismiss();
                    JSONObject json = new JSONObject(output);
                    String response = json.getString("response");
                    String message = json.getString("message");
                    JSONObject data_obj = json.getJSONObject("data");
                    String id = json.getString("id");
                    String customer_name = json.getString("customer_name");
                    String mobile_no = json.getString("mobile_no");
                    String address = json.getString("address");
                    String product_name = json.getString("product_name");
                    String model_no = json.getString("model_no");
                    String serial_no = json.getString("serial_no");
                    String complain_id = json.getString("complain_id");
                    String complain_no = json.getString("complain_no");
                    String status = json.getString("status");
                    String pin_code = json.getString("pin_code");

                    name.setText(customer_name);
                    mob_no.setText(mobile_no);
                    address_.setText(address);
                    model_no_.setText(model_no);
                    serial_no_.setText(serial_no);
                    pincode_.setText(pin_code);

                    Log.e("json>>>>>>>>>", json.toString());


                    if (response.equalsIgnoreCase("1")) {
                        dialog.dismiss();

                        //  manager.stroreCompCode(complain_no);
                        //  AppPreference.setStatus(ComplaintList.this, status);


                    } else {
                        Toast.makeText(getActivity(), response, Toast.LENGTH_LONG).show();
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                    dialog.dismiss();
                }
                super.onPostExecute(output);
            }

        }

    }

//********************************************************************************************


    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
       /* if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }*/

        try {
            mListener = (OnFragmentInteractionListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString()
                    + " must implement OnFragmentInteractionListener");

        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }


    public interface OnFragmentInteractionListener {

        void onFragmentInteraction(Uri uri);
    }

/*
    @Override
    public void setMenuVisibility(final boolean visible) {
        super.setMenuVisibility(visible);
        if (visible) {
            if (Connectivity.isNetworkAvailable(getActivity())) {
                new GetComplaintList().execute();
            } else {
                Toast.makeText(getActivity(), "no Internet", Toast.LENGTH_SHORT).show();
            }
        }
    }*/


}
