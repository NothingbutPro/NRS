package com.example.android.nrs;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import com.example.android.nrs.SharedPreference.SessionManager;
import com.example.android.nrs.Utility.Connectivity;
import com.example.android.nrs.Utility.RecyclerTouchListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ComplaintList extends AppCompatActivity {

    private List<Complaint> movieList = new ArrayList<>();
    private RecyclerView recyclerView;
    private ComplaintAdapter mAdapter;
    private ImageView staff_profile;
    private ImageView staff_image, logout;
    String server_url;
    String Complaint_no, profile;
    LinearLayout pending, closed;
    AppPreference logoutSession;
    private SessionManager manager;
    private String complain_no;
    // String status;
    TextView forgetPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_complaint_list);
        manager = new SessionManager(this);
        staff_image = (ImageView) findViewById(R.id.person);

        Complaint_no = AppPreference.getComplaintId(ComplaintList.this);

        profile = AppPreference.getProfile(ComplaintList.this);


        logout = (ImageView) findViewById(R.id.logout);
        pending = (LinearLayout) findViewById(R.id.pending);
        closed = (LinearLayout) findViewById(R.id.closed);
        forgetPassword = (TextView)findViewById(R.id.forgetPassword);

        recyclerView = (RecyclerView) findViewById(R.id.recyclerview);

        staff_profile = (ImageView) findViewById(R.id.person_profile);
        staff_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                PopupMenu popup = new PopupMenu(ComplaintList.this, staff_profile);
                //Inflating the Popup using xml file
                popup.getMenuInflater().inflate(R.menu.poupup_menu, popup.getMenu());

                //registering popup with OnMenuItemClickListener
                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    public boolean onMenuItemClick(MenuItem item) {
                        Intent intent = new Intent(ComplaintList.this, StaffProfile.class);
                        startActivity(intent);
                        return true;
                    }
                });

                popup.show();//showing popup menu
            }

        });


        if (Connectivity.isNetworkAvailable(this)) {
            new GetComplaintList().execute();
        }else {
            Toast.makeText(this, "No Internet", Toast.LENGTH_SHORT).show();
        }

        logoutSession = new AppPreference(ComplaintList.this);

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                logoutSession.logoutSession();
                finish();
            }
        });

        recyclerView.addOnItemTouchListener(new RecyclerTouchListener(ComplaintList.this, recyclerView, new RecyclerTouchListener.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                Complaint complaint=movieList.get(position);
                String CompCode=complaint.getComplaint_code();
                manager.stroreCompCode(CompCode);
                Intent intent = new Intent(view.getContext(),NewFeedbackActivity.class);
//              intent.putExtra("CompCode",CompCode);
                startActivity(intent);
            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));



    }


    class GetComplaintList extends AsyncTask<String, String, String> {
        String output = "";
        ProgressDialog dialog;

        @Override
        protected void onPreExecute() {
            dialog = new ProgressDialog(ComplaintList.this);
            dialog.setMessage("Processing");
            dialog.setCancelable(true);
            dialog.show();
            super.onPreExecute();
            //movieList = new ArrayList<>();
        }

        @Override
        protected String doInBackground(String... params) {

            try {
                server_url = "http://spellclasses.co.in/NRS/api/complian_show?complain_id=" + Complaint_no;

            } catch (Exception e) {
                e.printStackTrace();
            }
            Log.e("sever_url>>>>>>>>>", server_url);
            output = HttpHandler.makeServiceCall(server_url);
            System.out.println("getcomment_url" + output);
            return output;
        }

        @Override
        protected void onPostExecute(String output) {
            if (output == null) {
                dialog.dismiss();
            } else {
                try {
                    dialog.dismiss();
                    JSONObject json = new JSONObject(output);
                    String response = json.getString("response");
                    String message = json.getString("message");
                    JSONArray message_array = json.getJSONArray("data");
                    for (int i = 0; i < message_array.length(); i++) {
                        JSONObject m = message_array.getJSONObject(i);
                        String id = m.getString("id");
                        String customer_name = m.getString("customer_name");
                        String mobile_no = m.getString("mobile_no");
                        String address = m.getString("address");
                        String product_name = m.getString("product_name");
                        String model_no = m.getString("model_no");
                        String serial_no = m.getString("serial_no");
                        String complain_id = m.getString("complain_id");
                        complain_no = m.getString("complain_no");
                        String status = m.getString("status");
                        Complaint complaintCons = new Complaint();
                        complaintCons.setComplaint_code(complain_no);
                        complaintCons.setName(customer_name);
                        complaintCons.setMobile_no(mobile_no);
                        complaintCons.setLocation(address);
                        complaintCons.setProductName(product_name);

                        movieList.add(complaintCons);


                    }

                    mAdapter = new ComplaintAdapter(movieList);
                    RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
                    recyclerView.setLayoutManager(mLayoutManager);
                    recyclerView.setItemAnimator(new DefaultItemAnimator());
                    recyclerView.setAdapter(mAdapter);


                    Log.e("json>>>>>>>>>", json.toString());


                    if (response.equalsIgnoreCase("1")) {
                        dialog.dismiss();

                        manager.stroreCompCode(complain_no);

                        //  AppPreference.setStatus(ComplaintList.this, status);


                    } else {
                        Toast.makeText(ComplaintList.this, response, Toast.LENGTH_LONG).show();
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                    dialog.dismiss();
                }
                super.onPostExecute(output);
            }

        }

    }

    public void onBackPressed() {
        Intent intent = new Intent(ComplaintList.this, MainActivity.class);
        startActivity(intent);
        //ComplaintList.this.finish();
    }


  /*  @Override
    public boolean onKeyDown(int keyCode, KeyEvent event)
    {
        if ((keyCode == KeyEvent.KEYCODE_BACK))
        {

            finish();

           *//* username.setText("");
            password.setText("");*//*

        }
        return super.onKeyDown(keyCode, event);
    }*/
}
