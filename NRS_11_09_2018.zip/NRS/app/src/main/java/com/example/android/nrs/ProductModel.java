package com.example.android.nrs;

/**
 * Created by android on 5/24/2018.
 */

public class ProductModel {
    String detail;
    String rate;

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public String getRate() {
        return rate;
    }

    public void setRate(String rate) {
        this.rate = rate;
    }
}
