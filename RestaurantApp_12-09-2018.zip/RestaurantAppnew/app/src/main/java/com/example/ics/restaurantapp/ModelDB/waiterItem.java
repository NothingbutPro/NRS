package com.example.ics.restaurantapp.ModelDB;

/**
 * Created by ICS on 25/05/2018.
 */

public class waiterItem {
    private String w_id,w_name,alias,waiter_id,outlet_id,discount_amo;

    public waiterItem() {
    }

    public waiterItem(String w_id, String w_name, String alias, String waiter_id, String outlet_id, String discount_amo) {
        this.w_id = w_id;
        this.w_name = w_name;
        this.alias = alias;
        this.waiter_id = waiter_id;
        this.outlet_id = outlet_id;
        this.discount_amo = discount_amo;
    }

    public String getW_id() {
        return w_id;
    }

    public void setW_id(String w_id) {
        this.w_id = w_id;
    }

    public String getW_name() {
        return w_name;
    }

    public void setW_name(String w_name) {
        this.w_name = w_name;
    }

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    public String getWaiter_id() {
        return waiter_id;
    }

    public void setWaiter_id(String waiter_id) {
        this.waiter_id = waiter_id;
    }

    public String getOutlet_id() {
        return outlet_id;
    }

    public void setOutlet_id(String outlet_id) {
        this.outlet_id = outlet_id;
    }

    public String getDiscount_amo() {
        return discount_amo;
    }

    public void setDiscount_amo(String discount_amo) {
        this.discount_amo = discount_amo;
    }
}
