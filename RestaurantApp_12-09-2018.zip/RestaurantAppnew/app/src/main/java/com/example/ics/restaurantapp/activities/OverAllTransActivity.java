package com.example.ics.restaurantapp.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.ics.restaurantapp.R;

public class OverAllTransActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_over_all_trans);
    }
}
