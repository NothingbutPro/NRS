package com.example.ics.restaurantapp.model;

/**
 * Created by Ics on 7/26/2018.
 */

public class PrintModel {
    String name;
    String qty;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getQty() {
        return qty;
    }

    public void setQty(String qty) {
        this.qty = qty;
    }
}
