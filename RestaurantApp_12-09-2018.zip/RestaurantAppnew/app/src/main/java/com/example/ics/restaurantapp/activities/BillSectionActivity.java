package com.example.ics.restaurantapp.activities;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ics.restaurantapp.DbHelper.DatabaseHelper;
import com.example.ics.restaurantapp.DbHelper.OrderDatabseHelper;
import com.example.ics.restaurantapp.Local.variables;
import com.example.ics.restaurantapp.ModelDB.kitchenOrderItem;
import com.example.ics.restaurantapp.ModelDB.waiterItem;
import com.example.ics.restaurantapp.R;
import com.example.ics.restaurantapp.SharedPreference.SessionManager;
import com.example.ics.restaurantapp.Utils.AppPrefences;
import com.example.ics.restaurantapp.Utils.MyApplication;
import com.example.ics.restaurantapp.adapter.BillItemAdapter;
import com.example.ics.restaurantapp.model.Menu_Items;
import com.example.ics.restaurantapp.model.PrintModel;
import com.hoin.btsdk.BluetoothService;
import com.hoin.btsdk.PrintPic;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Formatter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;

import io.paperdb.Paper;

public class BillSectionActivity extends AppCompatActivity {
    Boolean CheckConnection = true;
    RecyclerView recycler_item_list;
    ArrayList<HashMap<String, String>> bill_item_list;
    ArrayList<HashMap<String, String>> arl;
    private ArrayList<Menu_Items> menu_items = new ArrayList<>();
    private BillItemAdapter billItemAdapter;
    EditText discount_percentage, discount_amount, discountReason, recpNo, amountPaid, amountPaid1;
    TextView txttax, dicount, nonChargable, roundOff;
    ImageView btn_close;
    LinearLayout bill_type;
    String Outlet;
    private JSONArray arr;
    private JSONObject obj;
    Button btn_back, btn_discount, btn_nonchargeable, btn_discount1, bt_add, bt_cancel;
    LinearLayout layout_bill, layout_discount, manual_discount, subgroup_discount, view_discount, view_subgroup, line_discount, line_subgroup;
    public TextView tatal_amount;
    public static TextView amount;
    float bill_amount = 0;
    int total = 0;
    ArrayList<kitchenOrderItem> billSectionOrderList;
    private double discountedAmount, discountPercentage;
    Button billCash, billCard, billCustomerAccount, billSwiggy, billZomatoCash, billZomatoOnline, billUserOnline, billPaytm;
    TextView amountPaidTxtview1;
    Button btn_save, btn_printBill;
    float bill_discount;

    private int totalInt = 0;
    String guest_name, order_for, table_no;
    private String strBillCash;
    private String strPaytmCash;
    private String strCardCash;
    private String strOtherCash;
    private String floor_no, sgst, cgst, total_tax, bill_dicount, round_of, cash, card, paytm, uber_online;
    private double Beofer_tax_amount, Tax_amount, SGST, CGST, Total_Amount;
    private String Customer_name, Waiter_Name, Date_Time, Dinenig_Area, Table_No, Menu_Name, Payment_method;
    private String Bill_no = "";
    private double Discount_amount, Round_off_amount, Qty, Rate, Tax, Amount;
    private String waiter_name, order_by, date_time;
    private String serial_no, reciept_no;
    int countFroSr = 0;
    private String currentDateTime;
    private OrderDatabseHelper orderDatabseHelper;
    private DatabaseHelper helper;
    private static final String TAG = "BillSectionActivity";
    private int editFlag;
    int saveFlag = 0;
    float bill_tax = 0;
    BluetoothService mService = null;
    BluetoothDevice con_dev = null;
    String msg;
    private String check;
    private float f = 0;
    private float x = 0;
    private String amountS;
    private String waiterName;
    private String strPayment_method;
    private String stritemName, stritemQty, stritemRate, stritemTax, stritemAmount;
    private SessionManager sessionManager;
    private String strRaj = "1";
    private int count;
    private DatabaseHelper databaseHelper;
    private ArrayList<waiterItem> waiter_list;
    private String strWaiterName = "", strWaiterId = "", strDiscount = "";
    private String strTableNo = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bill_section);
        Date currentTime = Calendar.getInstance().getTime();
        SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss a");
        currentDateTime = sdf1.format(currentTime);
        orderDatabseHelper = new OrderDatabseHelper(this);
        databaseHelper = new DatabaseHelper(this);
        billSectionOrderList = new ArrayList<>();
        arr = new JSONArray();
        sessionManager = new SessionManager(this);
        mService = new BluetoothService(BillSectionActivity.this, mHandler);
        if (mService.isAvailable() == false) {
            Toast.makeText(BillSectionActivity.this, "Bluetooth is not available", Toast.LENGTH_LONG).show();
        }
        SharedPreferences sharedPreferences = getSharedPreferences("mishra", MODE_PRIVATE);
        String address = sharedPreferences.getString("device", "");
        if (address == null || address.equals("")) {

        } else {
            con_dev = mService.getDevByMac(address);
            mService.connect(con_dev);

        }
        gettingAllOrder();
        getWaiterData();

        bill_type = (LinearLayout) findViewById(R.id.bill_type);
        btn_close = (ImageView) findViewById(R.id.btn_close);
        btn_back = (Button) findViewById(R.id.btn_back);
        amount = (TextView) findViewById(R.id.amount);
        tatal_amount = (TextView) findViewById(R.id.tatal_amount);
        btn_discount = (Button) findViewById(R.id.btn_discount);
        btn_discount1 = (Button) findViewById(R.id.btn_discount1);
        btn_nonchargeable = (Button) findViewById(R.id.btn_nonchargeable);
        layout_bill = (LinearLayout) findViewById(R.id.layout_bill);
        layout_discount = (LinearLayout) findViewById(R.id.layout_discount);
        view_discount = (LinearLayout) findViewById(R.id.view_discount);

        discount_percentage = (EditText) findViewById(R.id.discount_percentage);
        discount_amount = (EditText) findViewById(R.id.discount_amount);
        discountReason = (EditText) findViewById(R.id.discountReason);

        recpNo = (EditText) findViewById(R.id.recpNo);
        amountPaid = (EditText) findViewById(R.id.amountPaid);
        amountPaid1 = (EditText) findViewById(R.id.amountPaid1);

        amountPaidTxtview1 = (TextView) findViewById(R.id.amountPaidTextview);

        btn_save = (Button) findViewById(R.id.btn_save);
        btn_printBill = (Button) findViewById(R.id.btn_printbill);

        txttax = (TextView) findViewById(R.id.tax);
        dicount = (TextView) findViewById(R.id.dicount);
        nonChargable = (TextView) findViewById(R.id.nonChargable);
        roundOff = (TextView) findViewById(R.id.roundOff);

        bt_add = (Button) findViewById(R.id.bt_add);
        bt_cancel = (Button) findViewById(R.id.bt_cancel);

        billCash = (Button) findViewById(R.id.billCash);
        billCard = (Button) findViewById(R.id.billCard);
        billUserOnline = (Button) findViewById(R.id.billUserOnline);
        billPaytm = (Button) findViewById(R.id.billPaytm);

        Outlet = AppPrefences.getOutlet(BillSectionActivity.this);
        if (billSectionOrderList.size() == 0) {
            txttax.setText("0");
            roundOff.setText("0");
            dicount.setText("0");
            nonChargable.setText("0");
            amount.setText("0");
            tatal_amount.setText("0");
            amountPaid1.setText("0");
            recpNo.setText("0");
//            variables.total_price=0;
//            NewActivity.txtTotal.setText(String.valueOf(variables.total_price));
            /*amountPaid1.setText("0");
            amountPaid1.setText("0");*/
        } else {
            for (kitchenOrderItem kitchenOrderItem : billSectionOrderList) {
                float v, v1;
                v = kitchenOrderItem.getRate();
                v1 = kitchenOrderItem.getQuantity();
                f = (v * v1) + f;
                Log.e("TOTAMO", f + "");
            }
            //-----------------------------------------------------------------------------

            final Cursor localCursor = orderDatabseHelper.getDataOfSelectedTable(variables.selecetd_table_data.getT_id(), variables.tableNumber);
            try {
                while (localCursor.moveToNext()) {
//                bill_amount = localCursor.getInt(6);
                    bill_amount = f;
//                    bill_tax = localCursor.getFloat(11);
                    bill_tax = (bill_amount * 5) / 100;
//                    bill_discount = localCursor.getFloat(13);
                    bill_discount = Float.parseFloat(strDiscount);
                    total = (int) (bill_amount + bill_tax);

                    Log.d("billamount", String.valueOf(total));
                }
            } catch (Exception e) {

            }

            Float y;
            float x = (float) Math.floor(bill_amount + bill_tax - bill_discount);
            if (x < 0) {
                x = 0;
                y = (bill_amount + bill_tax - x);
            }
            y = (bill_amount + bill_tax - x);
            Double roundoff = BigDecimal.valueOf(y)
                    .setScale(3, RoundingMode.HALF_UP)
                    .doubleValue();
            String s = String.valueOf(roundoff);
            double val = roundoff;
            String[] arr = String.valueOf(val).split("\\.");
            int[] intArr = new int[2];
            intArr[0] = Integer.parseInt(arr[0]); // 1
            intArr[1] = Integer.parseInt(arr[1]); // 9
            roundOff.setText(String.valueOf("0." + intArr[1]));
            dicount.setText(String.valueOf(bill_discount));

            Double total_tax = BigDecimal.valueOf(bill_tax)
                    .setScale(3, RoundingMode.HALF_UP)
                    .doubleValue();

            tatal_amount.setText(String.valueOf(x));
            amount.setText(String.valueOf(bill_amount));
            txttax.setText(String.valueOf(total_tax));
            amountPaid1.setText(String.valueOf(x));
            helper = new DatabaseHelper(this);

            bill_item_list = new ArrayList<>();
            arl = new ArrayList<>();


            billItemAdapter = new BillItemAdapter(BillSectionActivity.this, billSectionOrderList);
            recycler_item_list = (RecyclerView) findViewById(R.id.recycler_item_list);
            recycler_item_list.setHasFixedSize(true);
            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(BillSectionActivity.this);
            linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
            recycler_item_list.setLayoutManager(linearLayoutManager);
            recycler_item_list.setAdapter(billItemAdapter);


        }
        btn_printBill.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StringBuffer sb = new StringBuffer();
                StringBuffer sb1 = new StringBuffer();
                Formatter fmt = new Formatter();
                sb.append("item" + "            " + "Qty");
                sb.append("\n");
                TextView t1 = null;
                Cursor localCursor = orderDatabseHelper.getAllCardOrderData();
                localCursor = orderDatabseHelper.getTableItemOrderInformation(variables.selecetd_table_data.getT_id(), variables.tableNumber);
                String s = "", s1 = "";
                int i = 0;
                while (localCursor.moveToNext()) {
                    List<String> strings = new ArrayList<>();
                    PrintModel printModel = new PrintModel();

                    s = localCursor.getString(2);
                    s1 = localCursor.getString(4);
                    strings.add(s);


                    msg = String.format("%-20s%s ", "item", "Qty");
                    // get the data into array, or class variable
                    String data = s;

                    sb.append(fmt.format("%4s", localCursor.getString(2)) + "" + fmt.format("%4s", localCursor.getString(4)));
                    sb.append("" + localCursor.getString(2) + "\n");
                    //  sb.append("\n");
                    Log.d("data", sb.toString());
                }


                String lang = getString(R.string.bluetooth_strLang);


                byte[] cmd = new byte[3];
                cmd[0] = 0x1b;
                cmd[1] = 0x21;
                if ((lang.compareTo("en")) == 0) {
                    cmd[2] |= 0x10;
                    mService.write(cmd);           //??????????
                    mService.sendMessage("Restaurant!\n", "GBK");
                    cmd[2] &= 0xEF;
                    mService.write(cmd);//??????????????

//                   localCursor = orderDatabseHelper.getTableItemOrderInformation(variables.selecetd_table_data.getT_id(), variables.tableNumber);

                    mService.sendMessage(msg + "\n" + sb.toString(), "GBK");
                } else if ((lang.compareTo("ch")) == 0) {
                    cmd[2] |= 0x10;
                    mService.write(cmd);           //??????????
                    mService.sendMessage("???????\n", "GBK");
                    cmd[2] &= 0xEF;
                    mService.write(cmd);           //??????????????
                    msg = "  ??????????????????????????????????\n"
                            + "  ??????????????????????????????????????????????????????????????????.\n";
                    mService.sendMessage(msg + "\n" + sb.toString(), "GBK");
                }

            }
        });


        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                /* float totAmo = Float.parseFloat(tatal_amount.getText().toString());
                if (totAmo <= 0) {
//                    orderDatabseHelper.UpdateData(variables.selecetd_table_data.getT_id(), variables.tableNumber);
//                    variables.selecetd_table_data = null;
                    Paper.book().write("total_pending", 0);
                    Intent intent = new Intent(BillSectionActivity.this, DrawerActivity.class);
                    startActivity(intent);
                    finish();
                } else{*/
//                    Paper.book().write("total_pending", Integer.parseInt(tatal_amount.getText().toString()));
                Intent intent = new Intent(BillSectionActivity.this, NewActivity.class);
                startActivity(intent);
                finish();
//                }

            }
        });

        btn_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bill_type.setVisibility(View.VISIBLE);
            }
        });

        btn_discount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                layout_bill.setVisibility(View.GONE);
                btn_discount.setVisibility(View.GONE);
                layout_discount.setVisibility(View.VISIBLE);
                btn_discount1.setVisibility(View.VISIBLE);
            }
        });

        discount_percentage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editFlag = 1;
                Log.d(TAG, "onClick: editText " + editFlag);
            }
        });

        discount_amount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editFlag = 0;
                Log.d(TAG, "onClick: editText " + editFlag);
            }
        });

        discount_percentage.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (editFlag == 1) {
                    String per = discount_percentage.getText().toString();
                    if (!per.equals("")) {
                        double percentage = (double) Double.parseDouble(per);
                        discountedAmount = ((bill_amount) * percentage) / 100;
                        discount_amount.setText(String.valueOf(discountedAmount));
                        //discount_amount.setText(String.valueOf(discountedAmount));
                        Log.d(TAG, "onTextChanged: raam");
                        Log.d(TAG, "onTextChanged: editFlag =" + editFlag);
                    } else {
                        discount_amount.setText("0");
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {
                Log.d(TAG, "afterTextChanged: hello");


            }
        });


        discount_amount.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (editFlag == 0) {
                    String amnt = discount_amount.getText().toString();
                    if (!amnt.equals("")) {
                        discountedAmount = (double) Double.parseDouble(discount_amount.getText().toString());
                        discountPercentage = (discountedAmount / bill_amount) * 100;
                        discount_percentage.setText(String.valueOf(discountPercentage));
                        Log.d(TAG, "onTextChanged: editFlag =" + editFlag);
                    } else {
                        discount_percentage.setText("0");
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected()) {
            Cursor cursorMenu = null;
            Cursor cursorOrder = null;
            CheckConnection = true;
            changeTextStatus(true);
            if (Bill_no != null) {
                cursorOrder = orderDatabseHelper.getAllOrderDetails();
                if (cursorOrder != null && cursorOrder.getCount() > 0) {

                    while (cursorOrder.moveToNext()) {
                        count++;
//String Customer_name, Waiter_Name, Date_Time, Dinenig_Area, Table_No, Menu_Name, Payment_method;
                        arr = new JSONArray();
                        String Bill_no = cursorOrder.getString(0);
                        String Customer_name = cursorOrder.getString(1);
                        String Dinenig_Area = cursorOrder.getString(2);
                        String Table_No = cursorOrder.getString(3);
                        String Waiter_Name = cursorOrder.getString(4);
                        String Date_Time = cursorOrder.getString(5);
                        double Beofer_tax_amount = Double.parseDouble(cursorOrder.getString(6));
                        double Tax_amount = Double.parseDouble(cursorOrder.getString(7));
                        double SGST = Double.parseDouble(cursorOrder.getString(8));
                        double CGST = Double.parseDouble(cursorOrder.getString(9));
                        double Total_Amount = Double.parseDouble(cursorOrder.getString(10));
                        double Discount_amount = Double.parseDouble(cursorOrder.getString(11));
                        double Round_off_amount = Double.parseDouble(cursorOrder.getString(12));
                        String Payment_method = cursorOrder.getString(13);
                        cursorMenu = orderDatabseHelper.getAllMenuItems(Bill_no);
                        if (cursorMenu != null && cursorMenu.getCount() > 0) {
                            menu_items.clear();
                            Log.e("Filling", "1");
                            while (cursorMenu.moveToNext()) {
                                String Menu_Name = cursorMenu.getString(1);
                                double Qty = Double.parseDouble(cursorMenu.getString(2));
                                double Rate = Double.parseDouble(cursorMenu.getString(3));
                                double Tax = Double.parseDouble(cursorMenu.getString(4));
                                double Amount = Double.parseDouble(cursorMenu.getString(5));
                                menu_items.add(new Menu_Items(Menu_Name, Qty + "", Rate + "", Tax + "", Amount + ""));
                            }
                            for (int i = 0; i < menu_items.size(); i++) {
                                arr.put(menu_items.get(i).getJSONObject());
                                String s = menu_items.get(i).getJSONObject().toString();
                            }
                            int i = orderDatabseHelper.deleteOrderDataByBillNo(Bill_no);
                            if (i == 1) {
                                new PostDataForOffline(Bill_no, Customer_name, Dinenig_Area, Table_No, Waiter_Name, Date_Time, Beofer_tax_amount + "", Tax_amount + "", SGST + ""
                                        , CGST + "", Total_Amount + "", Discount_amount + "", Round_off_amount + "", Payment_method, arr).execute();
                                Log.e("Bill_Number", "1");
                            } else {
                                Toast.makeText(this, "Some Thing Went Wrong To Sent Offline Data to Server", Toast.LENGTH_SHORT).show();
                                Log.e("Bill_Number", "0");
                            }
                        }
                        Log.e("Counting", count + "");
//                        int i= orderDatabseHelper.deleteOrderDataByBillNo(Bill_no);
                        /*if (i==1){
                            new PostDataForOffline().execute();
                            Log.e("Bill_Number","1");
                        }else {
                            Toast.makeText(this, "Some Thing Went Wrong To Sent Offline Data to Server", Toast.LENGTH_SHORT).show();
                            Log.e("Bill_Number","0");
                        }*/

                    }

                }

            } else {
                Log.e("Blank", "1");
            }
            Toast.makeText(this, "yes", Toast.LENGTH_SHORT).show();
        } else {
            CheckConnection = false;
            Toast.makeText(this, "go", Toast.LENGTH_SHORT).show();
        }
        btn_discount1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                layout_discount.setVisibility(View.GONE);
                btn_discount1.setVisibility(View.GONE);

                layout_bill.setVisibility(View.VISIBLE);
                btn_discount.setVisibility(View.VISIBLE);
            }
        });

        btn_nonchargeable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                amount.setText("0");
//                tax.setText("0");
//                dicount.setText("0");
//                nonChargable.setText("0");
//                roundOff.setText("0");
//                tatal_amount.setText("0");
//
//                orderDatabseHelper.updateOrderListItemDiscountMoney(
//                        variables.selecetd_table_data.getT_id(),
//                        0,
//                        0,
//                        0,
//                        variables.tableNumber
//                );
            }
        });

        recpNo.setText(String.valueOf(variables.generateReceiptNo(variables.receipt_no)));

        bt_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String reason = discountReason.getText().toString();
                String disAmo = discount_amount.getText().toString();
//                variables.selected_waiter_data.setDiscount_amo(disAmo);
                boolean b = orderDatabseHelper.Update_Discount(strWaiterId, strWaiterName, strTableNo, disAmo);
                if (b) {
                    Log.e("JAI HO", "JAI HO");
                } else {
                    Log.e("JAI HO", "NOTHING");
                }
                if (reason.equals("")) {
                    Toast.makeText(BillSectionActivity.this, "Please add the reason", Toast.LENGTH_SHORT).show();
                } else {
                    Double truncatedDicount = BigDecimal.valueOf(discountedAmount)
                            .setScale(3, RoundingMode.HALF_UP)
                            .doubleValue();

                    dicount.setText(String.valueOf(truncatedDicount));
                    layout_discount.setVisibility(View.GONE);
                    btn_discount1.setVisibility(View.GONE);

                    layout_bill.setVisibility(View.VISIBLE);
                    btn_discount.setVisibility(View.VISIBLE);
                    Float y;
                    float x = (float) Math.floor(bill_amount + bill_tax - discountedAmount);
                    y = (float) (bill_amount + bill_tax - discountedAmount - x);

                    roundOff.setText(String.valueOf(y));


                    /*
                    orderDatabseHelper.updateOrderListItemDiscountMoney(
                            variables.selecetd_table_data.getT_id(),
                            (int) x,
                            (int) x,
                            truncatedDicount,
                            variables.tableNumber
                    );*/
                    tatal_amount.setText(String.valueOf(x));
                    amountPaid1.setText(String.valueOf(x));
                    amountPaid.setText(String.valueOf(x));

                }
            }
        });

        bt_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                layout_discount.setVisibility(View.GONE);
                btn_discount1.setVisibility(View.GONE);

                layout_bill.setVisibility(View.VISIBLE);
                btn_discount.setVisibility(View.VISIBLE);
            }
        });


        billCash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveFlag = 1;
                amountPaidTxtview1.setText("Cash");
                strPayment_method = "Cash";
                amountPaid.setText(tatal_amount.getText().toString());
                billCard.setVisibility(View.GONE);
                billPaytm.setVisibility(View.GONE);
                billUserOnline.setVisibility(View.GONE);
            }
        });

        billCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveFlag = 2;
                strPayment_method = "Card";
                amountPaidTxtview1.setText("Card");
                amountPaid.setText(tatal_amount.getText().toString());
                billCash.setVisibility(View.GONE);
                billPaytm.setVisibility(View.GONE);
                billUserOnline.setVisibility(View.GONE);
            }
        });

     /*   billCustomerAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                amountPaidTxtview1.setText("Customer Account");
                amountPaid.setText(String.valueOf(bill_amount));
            }
        });

        billSwiggy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                amountPaidTxtview1.setText("Swiggy");
                amountPaid.setText(String.valueOf(bill_amount));
            }
        });

        billZomatoCash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                amountPaidTxtview1.setText("Zomato Cash");
                amountPaid.setText(String.valueOf(bill_amount));
            }
        });

        billZomatoOnline.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                amountPaidTxtview1.setText("Zomata Online");
                amountPaid.setText(String.valueOf(bill_amount));
            }
        });
*/
        billPaytm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveFlag = 3;
                strPayment_method = "Patym";
                amountPaidTxtview1.setText("Patym");
                amountPaid.setText(tatal_amount.getText().toString());
                billCash.setVisibility(View.GONE);
                billCard.setVisibility(View.GONE);
                billUserOnline.setVisibility(View.GONE);
            }
        });

        billUserOnline.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveFlag = 4;
                strPayment_method = "Other";
                amountPaidTxtview1.setText("Other");
                amountPaid.setText(tatal_amount.getText().toString());
                billCash.setVisibility(View.GONE);
                billPaytm.setVisibility(View.GONE);
                billCard.setVisibility(View.GONE);
            }
        });

        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double i = Double.parseDouble(tatal_amount.getText().toString());
                if (saveFlag == 0) {
                    Toast.makeText(BillSectionActivity.this, "Please choose any paying gateway", Toast.LENGTH_SHORT).show();
                } else {
                    if (i > 0) {
                        Cursor localCusor = orderDatabseHelper.getDataOfSelectedTable(variables.selecetd_table_data.getT_id(), variables.tableNumber);
                        int due = Paper.book().read("total_pending");
                        int net = Paper.book().read("net_sale");
                        localCusor.moveToNext();
                        int amm = localCusor.getInt(6);
                        Paper.book().write("total_pending", due - amm);
                        Paper.book().write("net_sale", amm + net);
                        Cursor paymentCursor = orderDatabseHelper.getPaymentOptions();
                        float ammo = Float.parseFloat(tatal_amount.getText().toString());
                        if (paymentCursor.getCount() == 0) {
                            if (saveFlag == 1) {
                                orderDatabseHelper.insertPaymentOptions(ammo, 0, 0, 0);
                            } else if (saveFlag == 2) {
                                orderDatabseHelper.insertPaymentOptions(0, ammo, 0, 0);
                            } else if (saveFlag == 3) {
                                orderDatabseHelper.insertPaymentOptions(0, 0, ammo, 0);
                            } else if (saveFlag == 4) {
                                orderDatabseHelper.insertPaymentOptions(0, 0, 0, ammo);
                            }
                        } else {
                            paymentCursor.moveToNext();
                            float precash = paymentCursor.getFloat(1);
                            float precard = paymentCursor.getFloat(2);
                            float prepaytm = paymentCursor.getFloat(3);
                            float preother = paymentCursor.getFloat(4);
                            if (saveFlag == 1) {
                                orderDatabseHelper.updatePaymentOptions(ammo + precash, precard, prepaytm, preother);
                            } else if (saveFlag == 2) {
                                orderDatabseHelper.updatePaymentOptions(precash, ammo + precard, prepaytm, preother);
                            } else if (saveFlag == 3) {
                                orderDatabseHelper.updatePaymentOptions(precash, precard, ammo + prepaytm, preother);
                            } else if (saveFlag == 4) {
                                orderDatabseHelper.updatePaymentOptions(precash, precard, prepaytm, ammo + preother);
                            }
                        }
                        orderDatabseHelper.updateOnFinishItem(variables.selecetd_table_data.getT_id(), 0, "Completed", variables.tableNumber);
                        orderDatabseHelper.trancateFreeTableItems(variables.selecetd_table_data.getT_id(), variables.tableNumber);
                        Cursor tableDetailsCursor = helper.getTableDetails(variables.selecetd_table_data.getT_id());
                        if (tableDetailsCursor.getCount() != 0) {
                            tableDetailsCursor.moveToNext();
                            if (!tableDetailsCursor.getString(8).equals("yes")) {
                                helper.updateTableStatus(variables.selecetd_table_data.getT_id(), "free");
                            } else {
                                if (variables.tableNumber.equals("1")) {
                                    orderDatabseHelper.updateOrderDetailsSplitNumber(variables.selecetd_table_data.getT_id(), "1", "2");
                                    orderDatabseHelper.updateATableItemOrderInformationSplitNumber(variables.selecetd_table_data.getT_id(), "1", "2");
                                } else {

                                }
                                helper.updateSplittedStatus(variables.selecetd_table_data.getT_id(), "no", variables.selected_waiter_data.getWaiter_id(), "");
                            }
                        }

                        variables.selecetd_table_data = null;
                        variables.selected_waiter_data.setDiscount_amo("0.0");
                        getDataForServer();
                        startActivity(new Intent(BillSectionActivity.this, DrawerActivity.class));
                        finish();
                    } else {
                        Toast.makeText(BillSectionActivity.this, "Amount Total Is Zero(0)", Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });


    }

    private void getWaiterData() {
        Cursor local = null;
        Cursor localWD = null;
//        waiter_list = new ArrayList<>();
        local = orderDatabseHelper.getWaiterWithDiscount();
        if (local != null) {
            while (local.moveToNext()) {
                strWaiterId = local.getString(0).toString();
                strWaiterName = local.getString(1).toString();
                strTableNo = local.getString(2).toString();
                strDiscount = local.getString(3).toString();
                Log.e("DiscountR", strWaiterId + "\n" + strDiscount);
                Log.e("DiscountRR", stritemName + "\n" + strTableNo);
                boolean b = orderDatabseHelper.Update_Discount(strWaiterId, strWaiterName, strTableNo, strDiscount);
                if (b) {
                    Log.e("YOYO_NEW", "JAI HO");
                } else {
                    Log.e("OHNO_NEW", "NOTHING");
                }
            }
        }
    }

    @SuppressLint("SdCardPath")
    private void printImage() {
        byte[] sendData = null;
        PrintPic pg = new PrintPic();
        pg.initCanvas(576);
        pg.initPaint();
        pg.drawImage(0, 0, "/mnt/sdcard/icon.jpg");
        //
        sendData = pg.printDraw();
        mService.write(sendData);   //???byte??????
        Log.d("????????", "" + sendData.length);
    }


    private void gettingAllOrder() {
        Cursor localCursor = orderDatabseHelper.getTableItemOrderInformation(variables.selecetd_table_data.getT_id(), variables.tableNumber);
        int i = 1;
        billSectionOrderList.clear();
        while (localCursor.moveToNext()) {
            if (localCursor.getInt(4) != 0) {
                if (localCursor.getInt(3) == 0) {
                    String item_id = localCursor.getString(1);
                    String item_name = localCursor.getString(2);
                    int item_quantity = localCursor.getInt(4);
                    float item_sgst_tax = localCursor.getFloat(6);
                    float item_cgst_tax = localCursor.getFloat(7);
                    float item_igst_tax = localCursor.getFloat(8);
                    float item_vat_tax = localCursor.getFloat(13);
                    showdialog(item_id, item_name, item_quantity, item_sgst_tax, item_cgst_tax, item_igst_tax, item_vat_tax);
                    break;
                } else {
                    totalInt = +localCursor.getInt(3);
                    Log.e("Toatl", totalInt + "");
                    billSectionOrderList.add(new kitchenOrderItem(
                                    localCursor.getString(1),
                                    localCursor.getString(2),
                                    i++,
                                    localCursor.getInt(3),
                                    localCursor.getInt(4),
                                    localCursor.getInt(5),
                                    localCursor.getInt(6),
                                    localCursor.getInt(7),
                                    localCursor.getInt(8),
                                    localCursor.getInt(9),
                                    localCursor.getInt(10),
                                    localCursor.getInt(11),
                                    localCursor.getInt(13),
                                    localCursor.getInt(14)
                            )
                    );
                }
            }
        }
    }

    private void showdialog(final String item_id, final String item_name, final int item_quantity, final float sgstTax, final float cgstTax, final float igstTax, final float vatTax) {
       /* AlertDialog.Builder a_builder = new AlertDialog.Builder(BillSectionActivity.this);
        a_builder.setMessage("Add price for " + item_name);
        a_builder.setCancelable(false);
        a_builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                int newRate= 0;   //set this newRate with the help editText used in your dialog
                updateItemRate(item_id, newRate,item_name,item_quantity,sgstTax,cgstTax,igstTax,vatTax);
            }
        });
        a_builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        AlertDialog alert = a_builder.create();
        alert.setTitle("Alert !!!");
        alert.show();*/
        LayoutInflater inflater = getLayoutInflater();
        View alertLayout = inflater.inflate(R.layout.custom_dialog, null);
        final EditText etUsername = alertLayout.findViewById(R.id.et_username);


        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setTitle("Info");
        // this is set the view from XML inside AlertDialog
        alert.setView(alertLayout);
        // disallow cancel of AlertDialog on click of back button and outside touch
        alert.setCancelable(false);
        alert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(getBaseContext(), "Cancel clicked", Toast.LENGTH_SHORT).show();
            }
        });

        alert.setPositiveButton("Done", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                String user = etUsername.getText().toString();
                int tt = Integer.valueOf(user) * item_quantity;
                orderDatabseHelper.Updateitem(item_id, String.valueOf(tt), user);
                billItemAdapter.notifyDataSetChanged();
                finish();
                startActivity(getIntent());

                Toast.makeText(getBaseContext(), "price: " + item_name + item_id, Toast.LENGTH_SHORT).show();
            }
        });
        AlertDialog dialog = alert.create();
        dialog.show();
    }


    private void updateItemRate(String item_id, int newRate, String item_name, int item_quantity, float sgstTax, float cgstTax, float igstTax, float vatTax) {
        if (newRate != 0) {
            orderDatabseHelper.updateTableItemOrderInformationTableRate(variables.selecetd_table_data.getT_id(),
                    variables.tableNumber,
                    newRate,
                    item_id);

            int price = newRate * item_quantity;

            if (vatTax != 0) {

                float tax = newRate * item_quantity * vatTax / 100;
                orderDatabseHelper.updatTableItemOrderInformation(
                        variables.selecetd_table_data.getT_id(),
                        item_id,
                        item_name,
                        newRate,
                        item_quantity,
                        price,
                        0,
                        0,
                        0,
                        tax,
                        variables.tableNumber
                );

                Cursor localCursor = orderDatabseHelper.getDataOfSelectedTable(variables.selecetd_table_data.getT_id(), variables.tableNumber);
                if (localCursor.getCount() != 0) {
                    while (localCursor.moveToNext()) {
                        int oldAmount = localCursor.getInt(6);
                        int oldDue = localCursor.getInt(7);
                        float oldTax = localCursor.getFloat(11);
                        orderDatabseHelper.updateOrderListItem(
                                variables.selecetd_table_data.getT_id(),
                                oldAmount + price,
                                oldDue + price,
                                "running",
                                oldTax + tax,
                                variables.tableNumber
                        );
                        Float y;
                        float x = (float) Math.floor(oldAmount + oldTax + price + tax);
                        y = (bill_amount + bill_tax - x);
                        Double roundoff = BigDecimal.valueOf(y)
                                .setScale(3, RoundingMode.HALF_UP)
                                .doubleValue();

                        roundOff.setText(String.valueOf(roundoff));

                        dicount.setText(String.valueOf(bill_discount));

                        Double total_tax = BigDecimal.valueOf(bill_tax)
                                .setScale(3, RoundingMode.HALF_UP)
                                .doubleValue();

                        tatal_amount.setText(String.valueOf(x));
                        amount.setText(String.valueOf(oldAmount + price));
                        txttax.setText(String.valueOf(oldTax + tax));

                    }
                }


            } else {
                float tax = newRate * item_quantity * (sgstTax + cgstTax + igstTax) / 100;
                float sgsttax = newRate * item_quantity * (sgstTax) / 100;
                float cgsttax = newRate * item_quantity * (cgstTax) / 100;
                float igsttax = newRate * item_quantity * (igstTax) / 100;
                orderDatabseHelper.updatTableItemOrderInformation(
                        variables.selecetd_table_data.getT_id(),
                        item_id,
                        item_name,
                        newRate,
                        item_quantity,
                        price,
                        sgsttax,
                        cgsttax,
                        igsttax,
                        0,
                        variables.tableNumber
                );

                Cursor localCursor = orderDatabseHelper.getDataOfSelectedTable(variables.selecetd_table_data.getT_id(), variables.tableNumber);
                if (localCursor.getCount() != 0) {
                    while (localCursor.moveToNext()) {
                        int oldAmount = localCursor.getInt(6);
                        int oldDue = localCursor.getInt(7);
                        float oldTax = localCursor.getFloat(11);
                        orderDatabseHelper.updateOrderListItem(
                                variables.selecetd_table_data.getT_id(),
                                oldAmount + price,
                                oldDue + price,
                                "running",
                                oldTax + tax,
                                variables.tableNumber
                        );

                        Float y;
                        float x = (float) Math.floor(oldAmount + oldTax + price + tax);
                        y = (bill_amount + bill_tax - x);
                        Double roundoff = BigDecimal.valueOf(y)
                                .setScale(3, RoundingMode.HALF_UP)
                                .doubleValue();

                        roundOff.setText(String.valueOf(roundoff));

                        dicount.setText(String.valueOf(bill_discount));

                        Double total_tax = BigDecimal.valueOf(bill_tax)
                                .setScale(3, RoundingMode.HALF_UP)
                                .doubleValue();

                        tatal_amount.setText(String.valueOf(x));
                        amount.setText(String.valueOf(oldAmount + price));
                        txttax.setText(String.valueOf(oldTax + tax));
                    }
                }

            }
            Toast.makeText(this, "Price added", Toast.LENGTH_SHORT).show();
//            gettingAllOrder();
        }
    }

    private final Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case BluetoothService.MESSAGE_STATE_CHANGE:
                    switch (msg.arg1) {
                        case BluetoothService.STATE_CONNECTED:   //??????
                            Toast.makeText(BillSectionActivity.this, "Connect successful", Toast.LENGTH_SHORT).show();

                            break;
                        case BluetoothService.STATE_CONNECTING:  //????????
                            Log.d("????????", "????????.....");
                            break;
                        case BluetoothService.STATE_LISTEN:     //????????????
                        case BluetoothService.STATE_NONE:
                            Log.d("????????", "???????.....");
                            break;
                    }
                    break;
                case BluetoothService.MESSAGE_CONNECTION_LOST:    //????????????
                    Toast.makeText(BillSectionActivity.this, "Device connection was lost",
                            Toast.LENGTH_SHORT).show();

                    break;
                case BluetoothService.MESSAGE_UNABLE_CONNECT:     //?????????
                    //   Toast.makeText(NewActivity.this, "Unable to connect device", Toast.LENGTH_SHORT).show();
                    break;
            }
        }

    };

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(BillSectionActivity.this, NewActivity.class);
        startActivity(intent);
        finish();
//        IsFinish("Want to close app?");
//        IsFinish("");

    }

    public void IsFinish(String alertmessage) {
        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case DialogInterface.BUTTON_POSITIVE:
                        /*Intent intent = new Intent(Intent.ACTION_MAIN);
                        intent.addCategory(Intent.CATEGORY_HOME);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);*/
                        Intent intent = new Intent(BillSectionActivity.this, DrawerActivity.class);
                        startActivity(intent);
                        finish();//                        android.os.Process.killProcess(android.os.Process.myPid());
                        // This above line close correctly
                        //finish();
                        break;

                    case DialogInterface.BUTTON_NEGATIVE:

                        break;
                }
            }
        };

        AlertDialog.Builder builder = new AlertDialog.Builder(BillSectionActivity.this);
        builder.setMessage(alertmessage)
                .setPositiveButton("Yes", dialogClickListener)
                .setNegativeButton("No", dialogClickListener).show();

    }

    private void getDataForServer() {
        Cursor localCursor = orderDatabseHelper.getCompletedOrderList();
        while (localCursor.moveToNext()) {
            Customer_name = localCursor.getString(5);
            Dinenig_Area = localCursor.getString(3);
            Table_No = localCursor.getString(10);
        }
//        Customer_name = "Hello";
        Waiter_Name = variables.selected_waiter_data.getW_name();
        Date_Time = currentDateTime;
        Beofer_tax_amount = Double.parseDouble(amount.getText().toString());
        Bill_no = recpNo.getText().toString();
        Tax_amount = Double.parseDouble(txttax.getText().toString());
        SGST = 2.5;
        CGST = 2.5;
        Total_Amount = Double.parseDouble(tatal_amount.getText().toString());
        if (discount_amount.getText().toString().equals("")) {
            Discount_amount = 0.0;
        } else {
            Discount_amount = Double.parseDouble(discount_amount.getText().toString());
        }
//        Discount_amount = Double.parseDouble();
        Round_off_amount = Double.parseDouble(roundOff.getText().toString());
        Payment_method = strPayment_method;
        menu_items.clear();
        for (kitchenOrderItem orderItem : billSectionOrderList) {
            stritemName = orderItem.getMname();
            int i = orderItem.getQuantity();
            int i1 = orderItem.getRate();
            stritemQty = String.valueOf(i);
            stritemRate = String.valueOf(i1);
            stritemTax = String.valueOf(orderItem.getTotalVatTax());
            int i2 = i * i1;
            stritemAmount = String.valueOf(i2);
            menu_items.add(new Menu_Items(stritemName, stritemQty, stritemRate, stritemTax, stritemAmount));
            orderDatabseHelper.setMenuItem(Bill_no, stritemName, stritemQty, stritemRate, stritemTax, stritemAmount);
        }
        for (int i = 0; i < menu_items.size(); i++) {
            arr.put(menu_items.get(i).getJSONObject());
            String s = menu_items.get(i).getJSONObject().toString();
        }
        //---------------- Call AsyncTask-----------------
        if (CheckConnection) {
            new PostData(Bill_no, Customer_name, Dinenig_Area, Table_No, Waiter_Name, Date_Time, Beofer_tax_amount + "", Tax_amount + "", SGST + ""
                    , CGST + "", Total_Amount + "", Discount_amount + "", Round_off_amount + "", Payment_method, arr).execute();
        } else {
            Cursor cursorMenu = null;
            orderDatabseHelper.getOrderDetails(Bill_no, Customer_name, Dinenig_Area, Table_No, Waiter_Name, Date_Time, Beofer_tax_amount + "", Tax_amount + "", SGST + ""
                    , CGST + "", Total_Amount + "", Discount_amount + "", Round_off_amount + "", Payment_method);
            sessionManager.setDiscount("0");
        }
    }

    // Method to change the text status
    public void changeTextStatus(boolean isConnected) {

        // Change status according to boolean value
       /* if (isConnected) {
            Cursor cursor = null;
            Cursor cursorMenu = null;
            cursor = orderDatabseHelper.getAllOrderDetails();
            while (cursor.moveToNext()) {
                Bill_no = cursor.getString(0);
                Customer_name = cursor.getString(1);
                Dinenig_Area = cursor.getString(2);
                Table_No = cursor.getString(3);
                Waiter_Name = cursor.getString(4);
                Date_Time = cursor.getString(5);
                Beofer_tax_amount = Double.parseDouble(cursor.getString(6));
                Tax_amount = Double.parseDouble(cursor.getString(7));
                SGST = Double.parseDouble(cursor.getString(8));
                CGST = Double.parseDouble(cursor.getString(9));
                Total_Amount = Double.parseDouble(cursor.getString(10));
                Discount_amount = Double.parseDouble(cursor.getString(11));
                Round_off_amount = Double.parseDouble(cursor.getString(12));
                Payment_method = cursor.getString(13);
            }
            cursorMenu = orderDatabseHelper.getAllMenuItems("00001");
            while (cursorMenu.moveToNext()) {
                Menu_Name=cursorMenu.getString(1);
                Qty= Double.parseDouble(cursorMenu.getString(2));
                Rate= Double.parseDouble(cursorMenu.getString(3));
                Tax= Double.parseDouble(cursorMenu.getString(4));
                Amount= Double.parseDouble(cursorMenu.getString(5));
            }
            Log.e("jjjjjjjjjj", "0");
        } else {
            Log.e("jjjjjjjjjj", "1");
//            CheckConnection = false;
        }*/
    }
    //---------------------------------------------------------

    public class PostData extends AsyncTask<String, Void, String> {

        private String Customer_name, Waiter_Name, Date_Time, Dinenig_Area, Table_No, Menu_Name, Payment_method;
        private String Bill_no = "";
        private String Discount_amount, Round_off_amount, Qty, Rate, Tax, Amount;
        private String Beofer_tax_amount, Tax_amount, SGST, CGST, Total_Amount;
        private JSONArray arr = new JSONArray();
        private String serial_no, reciept_no;

        public PostData(String bill_no, String customer_name, String dinenig_area, String table_no, String waiter_name, String date_time
                , String beofer_tax_amount, String tax_amount, String sGST, String cGST, String total_Amount, String discount_amount, String round_off_amount, String payment_method, JSONArray arr) {
            Bill_no = bill_no;
            Customer_name = customer_name;
            Dinenig_Area = dinenig_area;
            Table_No = table_no;
            Waiter_Name = waiter_name;
            Date_Time = date_time;
            Beofer_tax_amount = beofer_tax_amount;
            Tax_amount = tax_amount;
            SGST = sGST;
            CGST = cGST;
            Total_Amount = total_Amount;
            Discount_amount = discount_amount;
            Round_off_amount = round_off_amount;
            Payment_method = payment_method;
            this.arr = arr;
        }

        protected void onPreExecute() {
           /* dialog = new ProgressDialog(BillSectionActivity.this);
            dialog.setMessage("Processing");
            dialog.setCancelable(false);
            dialog.show();*/

        }

        protected String doInBackground(String... arg0) {

            try {

                URL url = new URL("http://twors.in/POS/Webservices/add_order");
                JSONObject postDataParams = new JSONObject();
                postDataParams.put("Bill_No", Bill_no);
                postDataParams.put("Customer_name", Customer_name);
                postDataParams.put("Dinenig_Area", Dinenig_Area);
                postDataParams.put("Table_No", Table_No);
                postDataParams.put("Waiter_Name", Waiter_Name);
                postDataParams.put("Date_Time", Date_Time);
                postDataParams.put("Beofer_tax_amount", Beofer_tax_amount);
                postDataParams.put("Tax_amount", Tax_amount);
                postDataParams.put("SGST", SGST);
                postDataParams.put("CGST", CGST);
                postDataParams.put("Total_Amount", Total_Amount);
                postDataParams.put("Discount_amount", Discount_amount);
                postDataParams.put("Round_off_amount", Round_off_amount);
                postDataParams.put("Payment_method", Payment_method);
                postDataParams.put("menulist", arr);

                Log.e("postDataParams", postDataParams.toString());

                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(15000);
                conn.setConnectTimeout(15000);
                conn.setRequestMethod("POST");
                conn.setDoInput(true);
                conn.setDoOutput(true);

                OutputStream os = conn.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = conn.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {

                    BufferedReader in = new BufferedReader(new
                            InputStreamReader(
                            conn.getInputStream()));

                    StringBuffer sb = new StringBuffer("");
                    String line = "";

                    while ((line = in.readLine()) != null) {

                        StringBuffer Ss = sb.append(line);
                        Log.e("Ss", Ss.toString());
                        sb.append(line);
                        break;
                    }

                    in.close();
                    return sb.toString();

                } else {
                    return new String("false : " + responseCode);
                }
            } catch (Exception e) {
                return new String("Exception: " + e.getMessage());
            }

        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null) {
                if (result.equals("{{")) {
                    sessionManager.setDiscount("0");
                    Intent intent = new Intent(BillSectionActivity.this, DrawerActivity.class);
                    startActivity(intent);
                    Toast.makeText(BillSectionActivity.this, "Oredr Saved Successfully", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(BillSectionActivity.this, "Not Saved", Toast.LENGTH_SHORT).show();
                }

            }
        }

        public String getPostDataString(JSONObject params) throws Exception {

            StringBuilder result = new StringBuilder();
            boolean first = true;

            Iterator<String> itr = params.keys();

            while (itr.hasNext()) {

                String key = itr.next();
                Object value = params.get(key);

                if (first)
                    first = false;
                else
                    result.append("&");

                result.append(URLEncoder.encode(key, "UTF-8"));
                result.append("=");
                result.append(URLEncoder.encode(value.toString(), "UTF-8"));

            }
            return result.toString();
        }
    }

    public class PostDataForOffline extends AsyncTask<String, Void, String> {
        int count_PostData;
        private String Customer_name, Waiter_Name, Date_Time, Dinenig_Area, Table_No, Menu_Name, Payment_method;
        private String Bill_no = "";
        private String Discount_amount, Round_off_amount, Qty, Rate, Tax, Amount;
        private String Beofer_tax_amount, Tax_amount, SGST, CGST, Total_Amount;
        private JSONArray arr = new JSONArray();
        private String serial_no, reciept_no;

        public PostDataForOffline(String bill_no, String customer_name, String dinenig_area, String table_no, String waiter_name, String date_time
                , String beofer_tax_amount, String tax_amount, String sGST, String cGST, String total_Amount, String discount_amount, String round_off_amount, String payment_method, JSONArray arr) {
            Bill_no = bill_no;
            Customer_name = customer_name;
            Dinenig_Area = dinenig_area;
            Table_No = table_no;
            Waiter_Name = waiter_name;
            Date_Time = date_time;
            Beofer_tax_amount = beofer_tax_amount;
            Tax_amount = tax_amount;
            SGST = sGST;
            CGST = cGST;
            Total_Amount = total_Amount;
            Discount_amount = discount_amount;
            Round_off_amount = round_off_amount;
            Payment_method = payment_method;
            this.arr = arr;
        }


        protected void onPreExecute() {
            count_PostData++;
           /* dialog = new ProgressDialog(BillSectionActivity.this);
            dialog.setMessage("Processing");
            dialog.setCancelable(false);
            dialog.show();*/
            Log.e("Counting PostData", count_PostData + "");

        }

        protected String doInBackground(String... arg0) {

            try {

                URL url = new URL("http://twors.in/POS/Webservices/add_order");
                JSONObject postDataParams = new JSONObject();
                postDataParams.put("Bill_No", Bill_no);
                postDataParams.put("Customer_name", Customer_name);
                postDataParams.put("Dinenig_Area", Dinenig_Area);
                postDataParams.put("Table_No", Table_No);
                postDataParams.put("Waiter_Name", Waiter_Name);
                postDataParams.put("Date_Time", Date_Time);
                postDataParams.put("Beofer_tax_amount", Beofer_tax_amount);
                postDataParams.put("Tax_amount", Tax_amount);
                postDataParams.put("SGST", SGST);
                postDataParams.put("CGST", CGST);
                postDataParams.put("Total_Amount", Total_Amount);
                postDataParams.put("Discount_amount", Discount_amount);
                postDataParams.put("Round_off_amount", Round_off_amount);
                postDataParams.put("Payment_method", Payment_method);
                postDataParams.put("menulist", arr);

                Log.e("postDataParams", postDataParams.toString());

                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(15000);
                conn.setConnectTimeout(15000);
                conn.setRequestMethod("POST");
                conn.setDoInput(true);
                conn.setDoOutput(true);

                OutputStream os = conn.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = conn.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {

                    BufferedReader in = new BufferedReader(new
                            InputStreamReader(
                            conn.getInputStream()));

                    StringBuffer sb = new StringBuffer("");
                    String line = "";

                    while ((line = in.readLine()) != null) {

                        StringBuffer Ss = sb.append(line);
                        Log.e("Ss", Ss.toString());
                        sb.append(line);
                        break;
                    }

                    in.close();
                    return sb.toString();

                } else {
                    return new String("false : " + responseCode);
                }
            } catch (Exception e) {
                return new String("Exception: " + e.getMessage());
            }

        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null) {
                if (result.equals("{{")) {
//                    Intent intent = new Intent(BillSectionActivity.this, DrawerActivity.class);
//                    startActivity(intent);

                    Toast.makeText(BillSectionActivity.this, "Offline Oredr Saved Successfully", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(BillSectionActivity.this, "Not Saved", Toast.LENGTH_SHORT).show();
                }

            }
        }

        public String getPostDataString(JSONObject params) throws Exception {

            StringBuilder result = new StringBuilder();
            boolean first = true;

            Iterator<String> itr = params.keys();

            while (itr.hasNext()) {

                String key = itr.next();
                Object value = params.get(key);

                if (first)
                    first = false;
                else
                    result.append("&");

                result.append(URLEncoder.encode(key, "UTF-8"));
                result.append("=");
                result.append(URLEncoder.encode(value.toString(), "UTF-8"));

            }
            return result.toString();
        }
    }

    @Override
    protected void onPause() {

        super.onPause();
        MyApplication.activityPaused();// On Pause notify the Application
    }

    @Override
    protected void onResume() {

        super.onResume();
        MyApplication.activityResumed();// On Resume notify the Application
    }


}
